// Application State (using variables instead of localStorage)
let currentAnalysisData = null;
let chartInstances = [];

// Model Configuration
const modelConfig = {
  accuracy: 0.8197,
  roc_auc: 0.907,
  features: ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal'],
  featureImportance: {
    cp: 0.1557,
    thal: 0.1196,
    thalach: 0.1122,
    oldpeak: 0.1097,
    ca: 0.0863,
    age: 0.0802,
    sex: 0.0745,
    restecg: 0.0698,
    slope: 0.0654,
    exang: 0.0621,
    trestbps: 0.0587,
    chol: 0.0543,
    fbs: 0.0515
  }
};

// Feature labels for display
const featureLabels = {
  age: 'Возраст',
  sex: 'Пол',
  cp: 'Тип боли',
  trestbps: 'АД в покое',
  chol: 'Холестерин',
  fbs: 'Сахар крови',
  restecg: 'ЭКГ покоя',
  thalach: 'Макс ЧСС',
  exang: 'Стенокардия',
  oldpeak: 'Депрессия ST',
  slope: 'Наклон ST',
  ca: 'Окраш. сосуды',
  thal: 'Талассемия'
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
  initializeTooltips();
  initializeForm();
});

// Tooltip functionality
function initializeTooltips() {
  const tooltipTriggers = document.querySelectorAll('.tooltip-trigger');
  const tooltip = document.getElementById('tooltip');
  
  tooltipTriggers.forEach(trigger => {
    trigger.addEventListener('mouseenter', function(e) {
      const text = this.getAttribute('data-tooltip');
      tooltip.textContent = text;
      tooltip.classList.remove('hidden');
      
      const rect = this.getBoundingClientRect();
      tooltip.style.left = rect.left + 'px';
      tooltip.style.top = (rect.bottom + 5) + 'px';
    });
    
    trigger.addEventListener('mouseleave', function() {
      tooltip.classList.add('hidden');
    });
  });
}

// Form initialization
function initializeForm() {
  const form = document.getElementById('analysisForm');
  
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (validateForm()) {
      const formData = collectFormData();
      performAnalysis(formData);
    }
  });
  
  form.addEventListener('reset', function() {
    setTimeout(() => {
      form.querySelectorAll('.form-control').forEach(input => {
        input.style.borderColor = '';
      });
    }, 0);
  });
}

// Navigation functions
function startAnalysis() {
  document.getElementById('landing').classList.add('hidden');
  document.getElementById('form').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showLanding() {
  document.getElementById('form').classList.add('hidden');
  document.getElementById('landing').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function newAnalysis() {
  document.getElementById('results').classList.add('hidden');
  document.getElementById('form').classList.remove('hidden');
  document.getElementById('analysisForm').reset();
  destroyCharts();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Form validation
function validateForm() {
  const form = document.getElementById('analysisForm');
  let isValid = true;
  
  // Check all required fields
  const requiredFields = form.querySelectorAll('[required]');
  requiredFields.forEach(field => {
    if (!field.value || (field.type === 'radio' && !form.querySelector(`input[name="${field.name}"]:checked`))) {
      field.style.borderColor = 'var(--color-danger-red)';
      isValid = false;
    } else {
      field.style.borderColor = '';
    }
  });
  
  if (!isValid) {
    alert('Пожалуйста, заполните все обязательные поля');
  }
  
  return isValid;
}

// Collect form data
function collectFormData() {
  const form = document.getElementById('analysisForm');
  const formData = new FormData(form);
  const data = {};
  
  // Convert form data to object
  data.age = parseInt(formData.get('age'));
  data.sex = parseInt(formData.get('sex'));
  data.cp = parseInt(formData.get('cp'));
  data.trestbps = parseInt(formData.get('trestbps'));
  data.chol = parseInt(formData.get('chol'));
  data.fbs = formData.get('fbs') ? 1 : 0;
  data.restecg = parseInt(formData.get('restecg'));
  data.thalach = parseInt(formData.get('thalach'));
  data.exang = formData.get('exang') ? 1 : 0;
  data.oldpeak = parseFloat(formData.get('oldpeak'));
  data.slope = parseInt(formData.get('slope'));
  data.ca = parseInt(formData.get('ca'));
  data.thal = parseInt(formData.get('thal'));
  
  return data;
}

// Perform analysis
function performAnalysis(data) {
  // Show loading overlay
  document.getElementById('loadingOverlay').classList.remove('hidden');
  
  // Simulate processing time
  setTimeout(() => {
    const prediction = predictHeartDisease(data);
    currentAnalysisData = { input: data, result: prediction };
    displayResults(prediction, data);
    
    // Hide loading and show results
    document.getElementById('loadingOverlay').classList.add('hidden');
    document.getElementById('form').classList.add('hidden');
    document.getElementById('results').classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, 1500);
}

// ML Prediction Logic (Simulated)
function predictHeartDisease(data) {
  let riskScore = 0;
  let riskFactors = [];
  
  // Age factor
  if (data.age > 60) {
    riskScore += 15;
    riskFactors.push({ level: 'high', text: 'Возраст старше 60 лет повышает риск сердечно-сосудистых заболеваний', icon: '👴' });
  } else if (data.age > 50) {
    riskScore += 8;
    riskFactors.push({ level: 'medium', text: 'Возраст 50-60 лет — умеренный фактор риска', icon: '🧑' });
  }
  
  // Chest pain type (cp)
  if (data.cp === 0) {
    riskScore += 20;
    riskFactors.push({ level: 'high', text: 'Типичная стенокардия — важный признак ишемической болезни', icon: '❤️‍🩹' });
  } else if (data.cp === 1) {
    riskScore += 12;
    riskFactors.push({ level: 'medium', text: 'Атипичная стенокардия требует дополнительного обследования', icon: '💓' });
  }
  
  // Blood pressure
  if (data.trestbps > 140) {
    riskScore += 10;
    riskFactors.push({ level: 'high', text: `Повышенное артериальное давление (${data.trestbps} мм рт.ст.)`, icon: '🩸' });
  } else if (data.trestbps > 130) {
    riskScore += 5;
    riskFactors.push({ level: 'medium', text: 'Пограничное повышение артериального давления', icon: '🩸' });
  }
  
  // Cholesterol
  if (data.chol > 240) {
    riskScore += 12;
    riskFactors.push({ level: 'high', text: `Высокий уровень холестерина (${data.chol} мг/дл)`, icon: '🧈' });
  } else if (data.chol > 200) {
    riskScore += 6;
    riskFactors.push({ level: 'medium', text: 'Умеренно повышенный холестерин', icon: '🧈' });
  }
  
  // Blood sugar
  if (data.fbs === 1) {
    riskScore += 8;
    riskFactors.push({ level: 'high', text: 'Повышенный уровень сахара в крови', icon: '🍬' });
  }
  
  // Maximum heart rate
  if (data.thalach < 100) {
    riskScore += 10;
    riskFactors.push({ level: 'high', text: 'Низкая максимальная частота сердечных сокращений', icon: '💗' });
  }
  
  // Exercise induced angina
  if (data.exang === 1) {
    riskScore += 15;
    riskFactors.push({ level: 'high', text: 'Стенокардия при физической нагрузке', icon: '🏃' });
  }
  
  // ST depression
  if (data.oldpeak > 2.0) {
    riskScore += 18;
    riskFactors.push({ level: 'high', text: `Значительная депрессия ST сегмента (${data.oldpeak})`, icon: '📉' });
  } else if (data.oldpeak > 1.0) {
    riskScore += 10;
    riskFactors.push({ level: 'medium', text: 'Умеренная депрессия ST сегмента', icon: '📉' });
  }
  
  // Number of vessels
  if (data.ca > 0) {
    riskScore += data.ca * 8;
    riskFactors.push({ level: 'high', text: `Обнаружено ${data.ca} окрашенных сосуда(ов) при флюороскопии`, icon: '🫀' });
  }
  
  // Thalassemia
  if (data.thal === 1 || data.thal === 3) {
    riskScore += 10;
    riskFactors.push({ level: 'medium', text: 'Обнаружен дефект при сканировании с таллием', icon: '🔬' });
  }
  
  // Calculate probability
  const probability = Math.min(Math.max(riskScore, 0), 100);
  const hasDisease = probability > 50;
  
  // If no risk factors found, add positive note
  if (riskFactors.length === 0) {
    riskFactors.push({ level: 'low', text: 'Основные показатели в пределах нормы', icon: '✅' });
  }
  
  return {
    probability: probability,
    hasDisease: hasDisease,
    riskLevel: probability > 70 ? 'ВЫСОКИЙ' : probability > 40 ? 'СРЕДНИЙ' : 'НИЗКИЙ',
    riskFactors: riskFactors,
    recommendations: generateRecommendations(hasDisease, probability, riskFactors)
  };
}

// Generate recommendations
function generateRecommendations(hasDisease, probability, riskFactors) {
  const recommendations = [];
  
  if (probability > 60) {
    recommendations.push({
      icon: '🏥',
      title: 'Срочная консультация кардиолога',
      text: 'Необходимо в ближайшее время обратиться к специалисту для детального обследования'
    });
    recommendations.push({
      icon: '🔬',
      title: 'Комплексное обследование',
      text: 'Рекомендуется пройти ЭКГ с нагрузкой, эхокардиографию, холтеровское мониторирование'
    });
    recommendations.push({
      icon: '💊',
      title: 'Медикаментозная терапия',
      text: 'Может потребоваться назначение препаратов для контроля давления и холестерина'
    });
  } else if (probability > 30) {
    recommendations.push({
      icon: '👨‍⚕️',
      title: 'Консультация врача',
      text: 'Рекомендуется обратиться к терапевту или кардиологу для оценки состояния'
    });
    recommendations.push({
      icon: '📊',
      title: 'Регулярный мониторинг',
      text: 'Контролируйте артериальное давление, уровень холестерина и сахара в крови'
    });
  } else {
    recommendations.push({
      icon: '✅',
      title: 'Профилактические осмотры',
      text: 'Проходите регулярные медицинские осмотры раз в год'
    });
  }
  
  // Universal recommendations
  recommendations.push({
    icon: '🥗',
    title: 'Здоровое питание',
    text: 'Придерживайтесь диеты с низким содержанием насыщенных жиров, соли и сахара'
  });
  recommendations.push({
    icon: '🏃‍♂️',
    title: 'Физическая активность',
    text: 'Уделяйте минимум 150 минут в неделю умеренной физической нагрузке'
  });
  recommendations.push({
    icon: '🚭',
    title: 'Отказ от вредных привычек',
    text: 'Избегайте курения и чрезмерного употребления алкоголя'
  });
  recommendations.push({
    icon: '😌',
    title: 'Управление стрессом',
    text: 'Практикуйте техники релаксации, йогу или медитацию'
  });
  
  return recommendations;
}

// Display results
function displayResults(prediction, inputData) {
  // Main result card
  const resultCard = document.getElementById('resultCard');
  const resultIcon = document.getElementById('resultIcon');
  const resultTitle = document.getElementById('resultTitle');
  const resultProbability = document.getElementById('resultProbability');
  const resultDescription = document.getElementById('resultDescription');
  const progressFill = document.getElementById('progressFill');
  
  if (prediction.hasDisease) {
    resultIcon.textContent = '🔴';
    resultTitle.textContent = 'ВЫСОКИЙ РИСК';
    resultTitle.style.color = 'var(--color-danger-red)';
    resultDescription.textContent = 'Обнаружены признаки повышенного риска сердечно-сосудистых заболеваний. Рекомендуется срочная консультация кардиолога.';
  } else {
    resultIcon.textContent = '🟢';
    resultTitle.textContent = 'НИЗКИЙ РИСК';
    resultTitle.style.color = 'var(--color-success-green)';
    resultDescription.textContent = 'Риск сердечно-сосудистых заболеваний находится в пределах нормы. Продолжайте вести здоровый образ жизни.';
  }
  
  resultProbability.textContent = `${prediction.probability.toFixed(1)}%`;
  progressFill.style.width = `${prediction.probability}%`;
  
  // Risk factors
  const riskFactorsList = document.getElementById('riskFactorsList');
  riskFactorsList.innerHTML = '';
  
  prediction.riskFactors.forEach(factor => {
    const item = document.createElement('div');
    item.className = `risk-item ${factor.level}`;
    item.innerHTML = `
      <div class="risk-icon">${factor.icon}</div>
      <div class="risk-content">
        <strong>${factor.text}</strong>
      </div>
    `;
    riskFactorsList.appendChild(item);
  });
  
  // Recommendations
  const recommendationsList = document.getElementById('recommendationsList');
  recommendationsList.innerHTML = '';
  
  prediction.recommendations.forEach(rec => {
    const item = document.createElement('div');
    item.className = 'recommendation-item';
    item.innerHTML = `
      <div class="recommendation-icon">${rec.icon}</div>
      <div class="recommendation-content">
        <strong>${rec.title}</strong>
        <span>${rec.text}</span>
      </div>
    `;
    recommendationsList.appendChild(item);
  });
  
  // Create charts
  createCharts(prediction, inputData);
}

// Create visualizations
function createCharts(prediction, inputData) {
  destroyCharts();
  
  // 1. Probability Pie Chart
  const probabilityCtx = document.getElementById('probabilityChart').getContext('2d');
  chartInstances.push(new Chart(probabilityCtx, {
    type: 'doughnut',
    data: {
      labels: ['Риск заболевания', 'Норма'],
      datasets: [{
        data: [prediction.probability, 100 - prediction.probability],
        backgroundColor: ['#ef4444', '#10b981'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return context.label + ': ' + context.parsed.toFixed(1) + '%';
            }
          }
        }
      }
    }
  }));
  
  // 2. Feature Importance Bar Chart
  const importanceCtx = document.getElementById('importanceChart').getContext('2d');
  const features = Object.keys(modelConfig.featureImportance);
  const importance = Object.values(modelConfig.featureImportance);
  
  chartInstances.push(new Chart(importanceCtx, {
    type: 'bar',
    data: {
      labels: features.map(f => featureLabels[f] || f),
      datasets: [{
        label: 'Важность',
        data: importance,
        backgroundColor: '#667eea',
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      indexAxis: 'y',
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        x: {
          beginAtZero: true,
          max: 0.2
        }
      }
    }
  }));
  
  // 3. Radar Chart - Comparison with normal values
  const radarCtx = document.getElementById('radarChart').getContext('2d');
  
  // Normalize values for radar chart
  const normalizedData = {
    'Возраст': Math.min(inputData.age / 100, 1),
    'АД': Math.min(inputData.trestbps / 200, 1),
    'Холестерин': Math.min(inputData.chol / 600, 1),
    'ЧСС макс': Math.min(inputData.thalach / 220, 1),
    'ST депрессия': Math.min(inputData.oldpeak / 6.5, 1)
  };
  
  const normalValues = [0.5, 0.6, 0.4, 0.7, 0.2];
  
  chartInstances.push(new Chart(radarCtx, {
    type: 'radar',
    data: {
      labels: Object.keys(normalizedData),
      datasets: [
        {
          label: 'Ваши показатели',
          data: Object.values(normalizedData),
          backgroundColor: 'rgba(239, 68, 68, 0.2)',
          borderColor: '#ef4444',
          borderWidth: 2
        },
        {
          label: 'Норма',
          data: normalValues,
          backgroundColor: 'rgba(16, 185, 129, 0.2)',
          borderColor: '#10b981',
          borderWidth: 2
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      scales: {
        r: {
          beginAtZero: true,
          max: 1
        }
      },
      plugins: {
        legend: {
          position: 'bottom'
        }
      }
    }
  }));
}

// Destroy existing charts
function destroyCharts() {
  chartInstances.forEach(chart => chart.destroy());
  chartInstances = [];
}

// Smooth scroll
function scrollToSection(sectionId) {
  const section = document.getElementById(sectionId);
  if (section) {
    section.scrollIntoView({ behavior: 'smooth' });
  }
}